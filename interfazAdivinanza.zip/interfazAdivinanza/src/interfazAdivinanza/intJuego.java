
package interfazAdivinanza;
import javax.swing.*;
 import java.awt.*;
 import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;
 import java.awt.event.MouseAdapter;
 import java.awt.event.MouseEvent;
import java.util.Random;

/**
 *
 * @author ROY2404
 */
public class intJuego extends javax.swing.JFrame {
    private Timer timer;
     private int tiempo;
     private int correctClicks;
     public int totalCorrectClicks;
     private Random random;
     private int indiceAdivinanzaActual;
     private String[] adivinanzas;
     private int numeroActual = 1;

    /**
     * Creates new form juagooooo
     */
    public intJuego() {
        this.totalCorrectClicks = UsuarioEmpezarJuego.obtenerNumero();
         this.random = new Random();
         indiceAdivinanzaActual = 0;
         this.adivinanzas = new String[]{
             "Vuelo entre las flores vivo en una colmena fabrico miel y también cera. ¿Quién soy?",
             "No es cama ni es león y desaparece en cualquier rincón. ¿Quién es?",          
             "Dos pinzas tengo y hacia atrás camino de mar o de río en el agua vivo. ¿Quién soy?",
             "No es más grande que una nuez sube al monte y no tiene pies.",
             "¿Cuál es la estrella que no tiene luz?",
             "Soy un trocito de luz en la noche. De día me escondo en la hierba. Parezco una esmeralda que el viento se lleva. ¿Quién soy?",
             "Soy un insecto que vuela entre las flores tengo dos alitas de muchos colores.",
             "Vuelo en la noche y duermo al revés,sin alas de plumas y sin ningún estrés¿Quién soy?",
             "Soy verde y salto con gran agilidad,vivo en el estanque con gran felicidad.¿Quién soy?",
             "El roer es mi trabajo el queso mi aperitivo y el gato siempre será mi más temido enemigo.¿Quién soy?"
         };
        initComponents();
        iniciarConteoTiempo();
        mostrarAdivinanzaAleatoria();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        labelTema = new java.awt.Label();
        jLabelJugador = new javax.swing.JLabel();
        labelTemaElegido = new java.awt.Label();
        labelTiempo = new java.awt.Label();
        labelAdivinanzaTitulo = new java.awt.Label();
        cuadroDeAdivinanza = new java.awt.Label();
        labelInstrucciones = new java.awt.Label();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        javax.swing.JLabel jLabelGifPensativo = new javax.swing.JLabel();
        labelBuenaSuerte = new java.awt.Label();
        jLabelaImagen1 = new javax.swing.JLabel();
        jLabelaImagen2 = new javax.swing.JLabel();
        jLabelaImagen3 = new javax.swing.JLabel();
        jLabelaImagen4 = new javax.swing.JLabel();
        jLabelaImagen5 = new javax.swing.JLabel();
        jLabelaImagen6 = new javax.swing.JLabel();
        jLabelaImagen7 = new javax.swing.JLabel();
        jLabelaImagen8 = new javax.swing.JLabel();
        jLabelaImagen9 = new javax.swing.JLabel();
        jLabelaImagen10 = new javax.swing.JLabel();
        java.awt.Label labelNombreJugador = new java.awt.Label(intInicio.obtenerNombre());
        labelPregunta = new java.awt.Label();
        jLabelTiempoCorre = new javax.swing.JLabel("0");
        labelNumPregunta = new java.awt.Label("1 de "+ totalCorrectClicks);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1850, 900));

        labelTema.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        labelTema.setText("TEMA :");

        jLabelJugador.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabelJugador.setText("JUGADOR :");

        labelTemaElegido.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        labelTemaElegido.setText("ANIMALES");

        labelTiempo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        labelTiempo.setText("TIEMPO :");

        labelAdivinanzaTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        labelAdivinanzaTitulo.setForeground(new java.awt.Color(0, 0, 51));
        labelAdivinanzaTitulo.setText("ADIVINANZA");

        cuadroDeAdivinanza.setBackground(new java.awt.Color(240, 245, 246));
        cuadroDeAdivinanza.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        cuadroDeAdivinanza.setForeground(new java.awt.Color(102, 0, 102));

        labelInstrucciones.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        labelInstrucciones.setText("INSTRUCCIONES:");

        jLabel1.setText("has click en la imagen correcta.");
        jLabel1.setToolTipText("");

        jLabel2.setText("Lee la adivinanza y luego ");


        jLabelGifPensativo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pensar.gif"))); // NOI18N
        jLabelGifPensativo.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(102, 102, 102)));
        labelBuenaSuerte.setText("¡¡BUENA SUERTE!!");

        jLabelaImagen1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/abeja.png"))); // NOI18N
        jLabelaImagen1.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen1MouseClicked(evt);
            }
        });
        jLabelaImagen1.addMouseListener(new ImageClickListener(1));


        jLabelaImagen2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/camaleon.png"))); // NOI18N
        jLabelaImagen2.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen2MouseClicked(evt);
            }
        });
        jLabelaImagen2.addMouseListener(new ImageClickListener(2));


        jLabelaImagen3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cangrejo.png"))); // NOI18N
        jLabelaImagen3.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen3MouseClicked(evt);
            }
        });
        jLabelaImagen3.addMouseListener(new ImageClickListener(3));


        jLabelaImagen4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/caracol.png"))); // NOI18N
        jLabelaImagen4.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen4MouseClicked(evt);
            }
        });
        jLabelaImagen4.addMouseListener(new ImageClickListener(4));


        jLabelaImagen5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/estrella.png"))); // NOI18N
        jLabelaImagen5.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen5MouseClicked(evt);
            }
        });
        jLabelaImagen5.addMouseListener(new ImageClickListener(5));


        jLabelaImagen6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/luciernaga.png"))); // NOI18N
        jLabelaImagen6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen6.addMouseListener(new ImageClickListener(6));

        jLabelaImagen7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/mariposa.png"))); // NOI18N
        jLabelaImagen7.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen7MouseClicked(evt);
            }
        });
        jLabelaImagen7.addMouseListener(new ImageClickListener(7));


        jLabelaImagen8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/murcielago.png"))); // NOI18N
        jLabelaImagen8.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen8MouseClicked(evt);
            }
        });
        jLabelaImagen8.addMouseListener(new ImageClickListener(8));


        jLabelaImagen9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/rana.png"))); // NOI18N
        jLabelaImagen9.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen9MouseClicked(evt);
            }
        });
        jLabelaImagen9.addMouseListener(new ImageClickListener(9));


        jLabelaImagen10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/raton.png"))); // NOI18N
        jLabelaImagen10.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.lightGray));
        jLabelaImagen10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelaImagen10MouseClicked(evt);
            }
        });
        jLabelaImagen10.addMouseListener(new ImageClickListener(10));


        labelPregunta.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        labelPregunta.setText("PREGUNTA: ");
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelaImagen1)
                    .addComponent(jLabelaImagen6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelaImagen7)
                    .addComponent(jLabelaImagen2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabelaImagen3)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelaImagen4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelaImagen5))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabelaImagen8)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelaImagen9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelaImagen10)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelTema, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(labelTemaElegido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelJugador))
                                .addGap(16, 16, 16))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(labelPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelNombreJugador, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelTiempoCorre, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelNumPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelAdivinanzaTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(188, 188, 188)
                        .addComponent(labelInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(165, 165, 165))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(cuadroDeAdivinanza, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(97, 97, 97))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelGifPensativo)
                .addGap(457, 457, 457))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelTema, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelTemaElegido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(labelNombreJugador, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabelJugador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelTiempoCorre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelTiempo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelNumPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelAdivinanzaTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cuadroDeAdivinanza, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelaImagen1)
                    .addComponent(jLabelaImagen2)
                    .addComponent(jLabelaImagen3)
                    .addComponent(jLabelaImagen4)
                    .addComponent(jLabelaImagen5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelaImagen10, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelaImagen6)
                    .addComponent(jLabelaImagen7)
                    .addComponent(jLabelaImagen8, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelaImagen9))
                .addGap(18, 18, 18)
                .addComponent(jLabelGifPensativo, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        setBounds(0, 0, 1168, 659);
    }// </editor-fold>  
    private void jLabelaImagen1MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen2MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen3MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen4MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen5MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen7MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen8MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen9MouseClicked(java.awt.event.MouseEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void jLabelaImagen10MouseClicked(java.awt.event.MouseEvent evt) {                                             
        // TODO add your handling code here:
    }
    private void iniciarConteoTiempo() {
        tiempo = 0;
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tiempo++;
                jLabelTiempoCorre.setText(String.valueOf(tiempo));
            }
        });
        timer.start();
    }
    public static String ObtenerEstadisticas() {
        // Calcula las estadísticas
        String estadisticas = "Estadísticas del Juego\n";
        estadisticas += "Nombre de Jugador: " + intInicio.obtenerNombre()+ "\n";
        estadisticas += "Numero de Preguntas: " + UsuarioEmpezarJuego.obtenerNumero()+"\n";
        estadisticas += "Tiempo total: "+UsuarioEmpezarJuego.obtenerNumero()+ " segundos\n";
        estadisticas += "Número de clics correctos: " + UsuarioEmpezarJuego.obtenerNumero() + "\n";
        estadisticas += "Número de adivinanzas completadas: " + UsuarioEmpezarJuego.obtenerNumero() + "\n";
        return estadisticas;

    }  
    private void detenerConteoTiempo() {
        if (timer != null) {
            timer.stop();
        }
    

        Object[] opciones = {"VolverAjugar", "Puntaje"};
        int seleccion = JOptionPane.showOptionDialog(this,
                "¡Felicidades! Has completado el juego.",
                "Fin del Juego",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opciones,
                opciones[0]);
    
        // Manejar la selección del usuario
        if (seleccion == 0) {
            // Código para VolverAjugar
            VolverAjugar();
        } else if (seleccion == 1) {
            // Código para ver puntaje
            VerPuntaje();
        }    }
    private void VerPuntaje() {
            // Crear y mostrar la nueva ventana
            Estadistica Estadistica = new Estadistica();
            Estadistica.setVisible(true);
            // Cerrar la ventana actual si es necesario
            this.dispose();
        
        
    }
        
    private void VolverAjugar() {
            
            // Crear y mostrar la nueva ventana
            UsuarioEmpezarJuego UsuarioEmpezarJuego = new UsuarioEmpezarJuego();
            UsuarioEmpezarJuego.setVisible(true);
            // Cerrar la ventana actual si es necesario
            this.dispose();
        
        
    }
    private void manejarClickImagen(int imagenNumero) {
        // Verificar si la imagen clickeada es la correcta
        if (esImagenCorrecta(imagenNumero)) {
            correctClicks++;
            mostrarAdivinanzaAleatoria();  // Mostrar una nueva adivinanza
            if (numeroActual <= totalCorrectClicks) {
                // Actualiza la etiqueta
                labelNumPregunta.setText(numeroActual + " de " + totalCorrectClicks);
                numeroActual++;
            } 
            // Verificar si todas las imágenes correctas han sido clickeadas
            if (correctClicks == totalCorrectClicks) {
                detenerConteoTiempo();
            }
        }
    }
    private void mostrarAdivinanzaAleatoria() {
        indiceAdivinanzaActual = random.nextInt(adivinanzas.length);
        cuadroDeAdivinanza.setText(adivinanzas[indiceAdivinanzaActual]);
    }

    private boolean esImagenCorrecta(int imagenNumero) {
        // Comprobar si la imagen clickeada corresponde a la adivinanza actual
        return imagenNumero == (indiceAdivinanzaActual + 1);
    }
    private class ImageClickListener extends MouseAdapter {
        private int imagenNumero;

        public ImageClickListener(int imagenNumero) {
            this.imagenNumero = imagenNumero;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            manejarClickImagen(imagenNumero);
        }
    }                                            

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(intJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(intJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(intJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(intJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new intJuego().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private java.awt.Label cuadroDeAdivinanza;
    private javax.swing.JLabel jLabelaImagen6;
    private javax.swing.JLabel jLabelJugador;
    private javax.swing.JLabel jLabelTiempoCorre;
    private javax.swing.JLabel jLabelaImagen1;
    private javax.swing.JLabel jLabelaImagen10;
    private javax.swing.JLabel jLabelaImagen2;
    private javax.swing.JLabel jLabelaImagen3;
    private javax.swing.JLabel jLabelaImagen4;
    private javax.swing.JLabel jLabelaImagen5;
    private javax.swing.JLabel jLabelaImagen7;
    private javax.swing.JLabel jLabelaImagen8;
    private javax.swing.JLabel jLabelaImagen9;
    private javax.swing.JLabel jLabel1 ;
    private javax.swing.JLabel jLabel2 ;
    private java.awt.Label labelAdivinanzaTitulo;
    private java.awt.Label labelBuenaSuerte;
    private java.awt.Label labelInstrucciones;
    private java.awt.Label labelNumPregunta;
    private java.awt.Label labelPregunta;
    private java.awt.Label labelTema;
    private java.awt.Label labelTemaElegido;
    private java.awt.Label labelTiempo;
    // End of variables declaration                   
}

